<?php

namespace Laravel\Fortify\Events;

class ValidTwoFactorAuthenticationCodeProvided extends TwoFactorAuthenticationEvent
{
    //
}
