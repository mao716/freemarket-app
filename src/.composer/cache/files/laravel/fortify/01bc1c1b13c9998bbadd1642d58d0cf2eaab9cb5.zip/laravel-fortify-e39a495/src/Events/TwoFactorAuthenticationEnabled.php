<?php

namespace Laravel\Fortify\Events;

class TwoFactorAuthenticationEnabled extends TwoFactorAuthenticationEvent
{
    //
}
